StudyForge – vollständiges Backup
Erstellt: 2026-10-21T06:34:52.276Z
App-Version: 1.0.0

Diese Datei enthält alle strukturierten Daten (data.json) und alle
Anhänge/Dokumente (Ordner files/). Wiederherstellung in StudyForge
unter „Sichern & Wiederherstellen“ → „Backup einlesen“.

Wichtig: Nicht einzelne Dateien aus dem Archiv verändern, sonst
schlägt die Prüfsummenkontrolle fehl.